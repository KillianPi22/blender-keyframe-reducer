# Keyframe Reducer 1.0.0

Add-on gratuit pour Blender 5.2, développé et testé dans Blender **5.2.1 LTS**.
Réduction inspirée du travail avec le Key Reducer de Cinema 4D ; ce n'est pas une
reproduction de son algorithme ni de sa fonction Magnet.

## Installation

1. Décompresser le **pack** de livraison.
2. Dans Blender : **Edit > Preferences > Add-ons > menu en haut à droite > Install from Disk**.
3. Sélectionner **keyframe_reducer-1.0.0.zip**, sans décompresser ce ZIP interne.
4. Activer **Keyframe Reducer** si nécessaire.
5. Dans la vue 3D ou le Graph Editor : appuyer sur **N**, puis ouvrir **Key Reducer**.

Blender 5.2.0 minimum. Aucune dépendance, connexion réseau, inscription ou permission spéciale.

## Utilisation

1. Sélectionner l'armature et son **Action active**, avec le bon slot.
2. Pour un montage NLA complet, effectuer d'abord **Strip > Bake Action** dans le NLA
   (Visual Keying activé, Pose, pas d'écrasement de l'Action), puis désactiver les pistes
   NLA originales. L'add-on réduit une Action, pas directement la pile NLA.
3. Choisir une **Force**, puis **Réduire sur une copie**.
4. Lire l'animation et alterner **Original / Réduit** pour comparer.
5. Ajuster la Force ou les tolérances et cliquer sur **Recalculer depuis la source**.
   Le calcul repart de l'original, sans accumuler les réductions.
6. Cliquer sur **Conserver la copie pour retouche**, puis corriger les clés dans le Graph Editor.

Les Actions originales et réduites sont conservées à l'enregistrement du .blend.
La réduction n'écrit aucun fichier à votre place. Enregistrer votre projet normalement.
La comparaison reste disponible après sauvegarde et réouverture si l'add-on est activé.
Les modifications manuelles faites à la copie avant **Conserver** sont remplacées lors
du prochain recalcul ; terminer la comparaison avant de retoucher les clés.

## Réglages

| Option | Effet |
|---|---|
| Force | Multiplie les tolérances. 0,5 conserve davantage de détails ; 1 est le réglage initial ; 2 autorise deux fois plus d'écart. |
| Bézier lisse | Reconstruit les poignées Auto Clamped, préserve la vitesse aux extrémités, puis contrôle les courbes réellement évaluées par Blender. |
| Linéaires | Garde une interpolation linéaire, utile pour les données mocap et parfois plus efficace. |
| Position | Écart vectoriel maximal **en unités locales**, avant l'échelle de l'armature. Dans la scène test, le rig est à 0,01 : 0,1 unité locale correspond à environ 0,001 unité monde pour une translation directe. |
| Rotation | Écart angulaire des quaternions ; pour Euler, écart vectoriel des angles non repliés, pour conserver les rotations complètes. Valeur initiale : 0,5°. |
| Échelle | Écart vectoriel des facteurs d'échelle ; initialement 0,001. |
| Os sélectionnés | Ne traite que les os sélectionnés en Pose Mode. Aucun effet sur les autres os ni les transformations de l'objet. |
| Extrema significatifs | Protège les changements de direction suffisamment marqués des courbes de position, d'échelle et d'Euler. Les quaternions sont protégés par la tolérance angulaire. |
| Extreme / Breakdown | Conserve les images des clés ayant ces types. Utile pour protéger une pose précise. |
| Vérification 0,25 image | Contrôle plus fin ; le réglage normal vérifie toutes les 0,5 image. Les temps des clés sources sont également vérifiés. |

Les clés sont alignées **par propriété** : XYZ position, XYZ échelle, XYZ Euler ou
WXYZ quaternion. L'add-on ne force pas tous les os ou toutes les propriétés à avoir
leurs poses aux mêmes images ; il ne déplace pas les clés comme Magnet de C4D.

## Protection et limites

- La source est copiée. Les autres slots de l'Action sont conservés tels quels.
- Les propriétés personnalisées, dont `lockInfluenceWeights` de Mixamo, sont conservées.
- Un canal verrouillé, muet, muni de modificateurs ou contenant une interpolation
  constante/spéciale entraîne la conservation de son groupe de transformation.
- Les quaternions incomplets ou avec inversion de signe sont conservés.
- Les groupes dont les canaux n'ont pas les mêmes images de début/fin sont conservés.
- Si la reconstruction ne respecte pas la tolérance, le groupe original est restauré.
- Les bornes de chaque groupe et les clés marquées sont conservées. Les clés de sortie
  utilisent les temps des clés existantes ; aucune clé fractionnaire supplémentaire.
- **La vérification porte sur des échantillons de transformations locales**, pas sur une
  garantie continue entre tous les instants, ni sur la position mondiale des pieds.
  Les petites différences de rotation s'accumulent le long de la chaîne du squelette.
  Une correction IK ou des clés de contact peut donc rester nécessaire.
- La réduction n'efface pas automatiquement les tremblements ou les erreurs de mocap.
- Travail sur l'Action active uniquement ; sortir du Tweak Mode avant utilisation.

## Scène test livrée

`TestImportMixamoAnim1_KeyReducer.blend` est une **copie** de la scène fournie.
Le mouvement visible de 1 à 250 a été baké en `KR_Montage_Source`, puis réduit.
Les pistes NLA sont conservées, mais leur évaluation est désactivée sur l'armature
pour ne pas superposer le montage original à son bake. L'Action réduite est active.
Les boutons Original / Réduit permettent de comparer les deux Actions.

Avec Force 1, rotation 0,5°, Bézier, contrôle toutes les 0,25 image :

| Test | Avant | Après | Réduction |
|---|---:|---:|---:|
| Swing isolé | 38 480 | 14 840 | 61,4 % |
| DropKick isolé | 45 760 | 17 854 | 61,0 % |
| Montage baké 1–250 | 164 750 | 89 062 | 45,9 % |

L'Action déjà éditée `Action` est plus conservatrice : 6 781 → 6 037 clés.
Ses canaux ont souvent des bornes différentes et sont alors laissés intacts.

Le bake reproduit le montage original à environ 0,0000035 unité monde près sur
les positions des os contrôlées à chaque image. Après réduction du montage,
l'écart maximal mesuré est d'environ **0,0138 unité monde**, dont 0,0127 sur
les extrémités mains/pieds. À l'échelle métrique de cette scène, cela correspond
à environ **1,4 cm**. Réduire la tolérance angulaire pour les contacts précis.
Ces mesures décrivent cette scène et ces réglages, pas toutes les animations.

25 contrôles automatiques supplémentaires ont passé : copie intacte, second slot,
clés marquées, alignement XYZ, quaternions, tours Euler, canaux verrouillés,
comparaison, recalcul, nettoyage des anciennes copies inutilisées et échec sans
modification de la source. Les scripts et le rapport sont inclus dans le pack.

## Code et licence

Le ZIP d'installation contient le code Python intégral et le manifeste Blender.
Licence **GPL-3.0-or-later** ; voir LICENSE. Aucun code de Maxon n'est utilisé.
Cette version n'est affiliée ni à Maxon ni à la Blender Foundation.
