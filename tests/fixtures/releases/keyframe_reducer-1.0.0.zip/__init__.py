"""Keyframe Reducer: reduce an Action on a protected copy.

SPDX-License-Identifier: GPL-3.0-or-later
"""
bl_info = {
    'name': 'Keyframe Reducer',
    'author': 'Killian Pichon / Codex',
    'version': (1, 0, 0),
    'blender': (5, 2, 0),
    'location': 'Graph Editor > Sidebar > Key Reducer',
    'description': 'Reduction controlee des cles, XYZ synchronises et comparaison avant/apres',
    'category': 'Animation',
}

import json
import math
import uuid
from dataclasses import asdict

import bpy
from bpy.props import (BoolProperty, EnumProperty, FloatProperty, IntProperty,
                       PointerProperty, StringProperty)
from .engine import Settings, find_slot, slot_curves, reduce_action


class KR_Settings(bpy.types.PropertyGroup):
    strength: FloatProperty(name='Force', description='Multiplicateur des tolerances : plus haut = moins de cles',
                            default=1.0, min=0.01, max=20.0, soft_max=5.0, precision=2)
    position_error: FloatProperty(name='Position', description='Erreur vectorielle en unites LOCALES, avant echelle de l\'armature',
                                  default=0.1, min=0.000001, max=100.0, precision=4)
    rotation_error: FloatProperty(name='Rotation', description='Erreur angulaire quaternion ; ecart vectoriel des angles Euler',
                                  default=math.radians(0.5), min=0.000001, max=math.pi, subtype='ANGLE')
    scale_error: FloatProperty(name='Echelle', description='Erreur vectorielle des facteurs d\'echelle',
                               default=0.001, min=0.000001, max=1.0, precision=4)
    interpolation: EnumProperty(name='Courbes', items=[
        ('BEZIER', 'Bezier lisse', 'Poignees Auto Clamped, avec verification de l\'erreur'),
        ('LINEAR', 'Lineaires', 'Interpolation lineaire, adaptee aux imports mocap')], default='BEZIER')
    selected_only: BoolProperty(name='Os selectionnes uniquement', default=False,
                               description='Selection des os en Pose Mode ; sinon tous les canaux de transformation du slot actif')
    preserve_extrema: BoolProperty(name='Garder les extrema significatifs', default=True,
                                  description='Protege les changements de direction significatifs des canaux ; rotations quaternion controlees par erreur angulaire')
    preserve_marked: BoolProperty(name='Proteger Extreme / Breakdown', default=True,
                                 description='Conserve les images des cles marquees Extreme ou Breakdown, sur tout le groupe XYZ/WXYZ')
    dense_check: BoolProperty(name='Verification toutes les 0,25 image', default=False,
                             description='Controle plus fin ; sinon toutes les 0,5 image et aux cles originales')
    show_advanced: BoolProperty(name='Tolerances et options', default=False)
    source: PointerProperty(type=bpy.types.Action)
    reduced: PointerProperty(type=bpy.types.Action)
    slot_identifier: StringProperty()
    owner_token: StringProperty()
    before: IntProperty()
    after: IntProperty()
    groups: IntProperty()
    message: StringProperty()


def current_pair(ob):
    st = ob.kr_settings
    ad = ob.animation_data
    return bool(ad and st.source and st.reduced and ad.action in (st.source, st.reduced))


def assign(ob, action, identifier):
    slot = find_slot(action, identifier)
    if slot is None:
        raise ValueError('Le slot original n\'existe plus dans cette Action.')
    ad = ob.animation_data_create()
    ad.action = action
    ad.action_slot = slot
    ob.update_tag()


def run_reduction(context):
    ob = context.active_object
    if ob is None or ob.animation_data is None or ob.animation_data.action is None:
        raise ValueError('Assigne une Action active, ou bake ton montage NLA d\'abord.')
    ad = ob.animation_data
    if ad.use_tweak_mode:
        raise ValueError('Quitte le Tweak Mode avec Tab dans le NLA avant de reduire.')
    st = ob.kr_settings
    if current_pair(ob):
        source, identifier = st.source, st.slot_identifier
    else:
        source = ad.action
        if ad.action_slot is None:
            raise ValueError('Choisis le slot de l\'armature dans l\'Action Editor.')
        identifier = ad.action_slot.identifier
    selected = None
    if st.selected_only:
        if ob.type != 'ARMATURE' or ob.mode != 'POSE':
            raise ValueError('Passe en Pose Mode pour reduire les os selectionnes.')
        selected = {bone.name for bone in ob.data.bones if bone.select}
        if not selected:
            raise ValueError('Selectionne au moins un os.')
    settings = Settings(strength=st.strength, position_error=st.position_error,
                        rotation_error=st.rotation_error, scale_error=st.scale_error,
                        interpolation=st.interpolation, preserve_extrema=st.preserve_extrema,
                        preserve_marked=st.preserve_marked,
                        sample_step=0.25 if st.dense_check else 0.5, selected_bones=selected)
    result = source.copy()
    result.name = source.name + '_KR'
    wm = context.window_manager
    wm.progress_begin(0, 100)
    try:
        report = reduce_action(result, find_slot(result, identifier), settings,
                               progress=lambda done, total: wm.progress_update(done/total*100))
    except Exception:
        bpy.data.actions.remove(result)
        raise
    finally:
        wm.progress_end()
    old_result = st.reduced if current_pair(ob) else None
    if not st.owner_token:
        st.owner_token = uuid.uuid4().hex
    result['_kr_owner'] = st.owner_token
    result['kr_report'] = json.dumps(asdict(report), ensure_ascii=False)
    serial_settings = asdict(settings)
    if selected is not None:
        serial_settings['selected_bones'] = sorted(selected)
    result['kr_settings'] = json.dumps(serial_settings, ensure_ascii=False)
    result['kr_source_name'] = source.name
    source.use_fake_user = True
    result.use_fake_user = True
    st.source = source
    st.reduced = result
    st.slot_identifier = identifier
    st.before, st.after = report.before, report.after
    st.groups = report.reduced_groups
    st.message = ' / '.join(report.warnings)
    assign(ob, result, identifier)
    if old_result and old_result != source and old_result.get('_kr_owner') == st.owner_token:
        # Do not remove a result referenced by any other object, NLA strip,
        # or saved comparison. Only discard an unused generated preview.
        if old_result.users == int(old_result.use_fake_user):
            bpy.data.actions.remove(old_result)
    context.scene.frame_set(context.scene.frame_current, subframe=context.scene.frame_subframe)
    return report


class KR_OT_reduce(bpy.types.Operator):
    bl_idname = 'kr.reduce'
    bl_label = 'Reduire sur une copie'
    bl_description = 'Cree une copie reduite. Recalculer repart toujours de la source protegee'
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return bool(context.active_object)

    def execute(self, context):
        try:
            report = run_reduction(context)
        except Exception as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        percent = 100*(1-report.after/report.before) if report.before else 0
        self.report({'INFO'}, f'{report.before:,} -> {report.after:,} cles (-{percent:.1f} %)')
        return {'FINISHED'}


class KR_OT_compare(bpy.types.Operator):
    bl_idname = 'kr.compare'
    bl_label = 'Comparer'
    bl_description = 'Affiche la source ou la copie reduite sans modifier les cles'
    bl_options = {'REGISTER', 'UNDO'}
    reduced: BoolProperty(default=False)

    def execute(self, context):
        ob = context.active_object
        if not ob or not current_pair(ob):
            self.report({'ERROR'}, 'Aucune comparaison active pour cet objet.')
            return {'CANCELLED'}
        if ob.animation_data.use_tweak_mode:
            self.report({'ERROR'}, 'Quitte le Tweak Mode avant de comparer.')
            return {'CANCELLED'}
        st = ob.kr_settings
        try:
            assign(ob, st.reduced if self.reduced else st.source, st.slot_identifier)
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        context.scene.frame_set(context.scene.frame_current, subframe=context.scene.frame_subframe)
        return {'FINISHED'}


class KR_OT_finish(bpy.types.Operator):
    bl_idname = 'kr.finish'
    bl_label = 'Conserver la copie pour retouche'
    bl_description = 'Active la copie reduite et termine la comparaison. L\'original reste disponible dans les Actions'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        ob = context.active_object
        if not ob or not current_pair(ob) or ob.animation_data.use_tweak_mode:
            self.report({'ERROR'}, 'Comparaison indisponible ou Tweak Mode actif.')
            return {'CANCELLED'}
        st = ob.kr_settings
        try:
            assign(ob, st.reduced, st.slot_identifier)
        except ValueError as error:
            self.report({'ERROR'}, str(error))
            return {'CANCELLED'}
        st.source = None
        st.reduced = None
        st.slot_identifier = ''
        context.scene.frame_set(context.scene.frame_current, subframe=context.scene.frame_subframe)
        return {'FINISHED'}


def draw_panel(self, context):
    layout = self.layout
    ob = context.active_object
    if ob is None:
        layout.label(text='Selectionne ton armature.', icon='INFO')
        return
    st = ob.kr_settings
    ad = ob.animation_data
    action = ad.action if ad else None
    if action is None:
        layout.label(text='Aucune Action active.', icon='INFO')
        layout.label(text='Bake le montage NLA, puis reduis.')
        return
    pair = current_pair(ob)
    layout.label(text='Source : ' + (st.source.name if pair else action.name), icon='ACTION')
    if ad.use_tweak_mode:
        layout.label(text='Quitte le Tweak Mode (Tab).', icon='ERROR')
        return
    if ad.use_nla and any(not t.mute for t in ad.nla_tracks):
        box = layout.box()
        box.label(text='Des pistes NLA sont actives.', icon='INFO')
        box.label(text='Reduction de l\'Action active seule.')
    layout.prop(st, 'strength', slider=True)
    layout.prop(st, 'interpolation')
    if ob.type == 'ARMATURE':
        layout.prop(st, 'selected_only')
    layout.label(text='XYZ / quaternion toujours synchronises', icon='LINKED')
    layout.prop(st, 'show_advanced', icon='TRIA_DOWN' if st.show_advanced else 'TRIA_RIGHT', emboss=False)
    if st.show_advanced:
        box = layout.box()
        box.label(text='Tolerances a Force = 1')
        box.prop(st, 'position_error')
        box.label(text='Position : unites locales du rig')
        box.prop(st, 'rotation_error')
        box.prop(st, 'scale_error')
        box.prop(st, 'preserve_extrema')
        box.prop(st, 'preserve_marked')
        box.prop(st, 'dense_check')
    layout.operator('kr.reduce', text='Recalculer depuis la source' if pair else 'Reduire sur une copie', icon='MOD_DECIM')
    if pair:
        box = layout.box()
        percent = 100*(1-st.after/st.before) if st.before else 0
        box.label(text=f'{st.before:,} -> {st.after:,} cles')
        box.label(text=f'-{percent:.1f} % / {st.groups} groupes reduits')
        row = box.row(align=True)
        row.operator('kr.compare', text='Original', depress=action == st.source).reduced = False
        row.operator('kr.compare', text='Reduit', depress=action == st.reduced).reduced = True
        box.operator('kr.finish', icon='CHECKMARK')
        box.label(text='Conserver avant de retoucher les cles.')
        if st.message:
            box.label(text='Certains canaux sont preserves.', icon='INFO')
            box.label(text='Details : propriete kr_report de l\'Action.')
    layout.separator()
    layout.label(text='Controle local, pas de verrouillage des pieds.')


class KR_PT_graph(bpy.types.Panel):
    bl_label = 'Keyframe Reducer'
    bl_idname = 'KR_PT_graph'
    bl_space_type = 'GRAPH_EDITOR'
    bl_region_type = 'UI'
    bl_category = 'Key Reducer'
    draw = draw_panel


class KR_PT_view(bpy.types.Panel):
    bl_label = 'Keyframe Reducer'
    bl_idname = 'KR_PT_view'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Key Reducer'
    draw = draw_panel


CLASSES = (KR_Settings, KR_OT_reduce, KR_OT_compare, KR_OT_finish, KR_PT_graph, KR_PT_view)


def register():
    for cls in CLASSES:
        bpy.utils.register_class(cls)
    bpy.types.Object.kr_settings = PointerProperty(type=KR_Settings)


def unregister():
    del bpy.types.Object.kr_settings
    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


if __name__ == '__main__':
    register()
